# Application Streamlit - Rapport SmO₂

Upload your .xlsx and .txt files to generate a PDF report.